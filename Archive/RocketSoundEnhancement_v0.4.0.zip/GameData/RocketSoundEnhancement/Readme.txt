# RocketSoundEnhancement
Sounds Effects by: Ensou04

Requirements:
-Module Manager
-Smokescreen
-RealPlume

License
The contents of this pack are distributed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International (http://creativecommons.org/licenses/by-nc-sa/4.0/).
You are free to share and adapt the materials only for non-commercial purposes and when providing appropriate attribution. Any derivatives must be distributed under the same license. 
